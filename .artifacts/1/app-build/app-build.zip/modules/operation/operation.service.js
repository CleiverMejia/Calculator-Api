export class OperationService {
    adition(a, b) {
        return a + b;
    }
    substraction(a, b) {
        return a - b;
    }
    product(a, b) {
        return a * b;
    }
    division(a, b) {
        if (b === 0) {
            throw new Error("El segundo numero debe ser diferente a 0");
        }
        return a / b;
    }
}
//# sourceMappingURL=operation.service.js.map