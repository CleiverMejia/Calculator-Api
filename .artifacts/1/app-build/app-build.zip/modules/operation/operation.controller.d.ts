import type { Request, Response } from "express";
import { OperationService } from "./operation.service";
export declare class OperationController {
    private operationService;
    constructor(operationService?: OperationService);
    adition: (req: Request, res: Response) => void;
    substraction: (req: Request, res: Response) => void;
    product: (req: Request, res: Response) => void;
    division: (req: Request, res: Response) => void;
}
//# sourceMappingURL=operation.controller.d.ts.map