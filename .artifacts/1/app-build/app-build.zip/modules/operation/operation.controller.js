import { OperationService } from "./operation.service";
export class OperationController {
    operationService;
    constructor(operationService = new OperationService()) {
        this.operationService = operationService;
    }
    adition = (req, res) => {
        if (!req.body || !req.body.a || !req.body.b) {
            res.status(400).json({
                success: false,
                error: "Bad request",
            });
            return;
        }
        const { a, b } = req.body;
        const result = this.operationService.adition(+a, +b);
        res.status(200).json({
            success: true,
            result: result,
        });
    };
    substraction = (req, res) => {
        if (!req.body || !req.body.a || !req.body.b) {
            res.status(400).json({
                success: false,
                error: "Bad request",
            });
            return;
        }
        const { a, b } = req.body;
        const result = this.operationService.substraction(+a, +b);
        res.status(200).json({
            success: true,
            result: result,
        });
    };
    product = (req, res) => {
        if (!req.body || !req.body.a || !req.body.b) {
            res.status(400).json({
                success: false,
                error: "Bad request",
            });
            return;
        }
        const { a, b } = req.body;
        const result = this.operationService.product(+a, +b);
        res.status(200).json({
            success: true,
            result: result,
        });
    };
    division = (req, res) => {
        if (!req.body || !req.body.a || !req.body.b) {
            res.status(400).json({
                success: false,
                error: "Bad request",
            });
            return;
        }
        try {
            const { a, b } = req.body;
            const result = this.operationService.division(+a, +b);
            res.status(200).json({
                success: true,
                result: result,
            });
        }
        catch {
            res.status(500).json({
                success: false,
                error: "Internal server error",
            });
        }
    };
}
//# sourceMappingURL=operation.controller.js.map