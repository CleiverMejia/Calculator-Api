export declare class OperationService {
    adition(a: number, b: number): number;
    substraction(a: number, b: number): number;
    product(a: number, b: number): number;
    division(a: number, b: number): number;
}
//# sourceMappingURL=operation.service.d.ts.map